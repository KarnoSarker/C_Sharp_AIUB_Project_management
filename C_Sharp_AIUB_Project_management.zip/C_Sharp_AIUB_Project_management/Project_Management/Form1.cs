﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using ExcelDataReader;
using System.Xml;
using System.Resources;
using System.Data.OleDb;
using LinqToExcel;
using Remotion.Data.Linq;
using System.Data.SqlClient;
using System.Diagnostics;


namespace Project_Management
{
    public partial class Form1 : Form
    {   
        int num = 0;
        int MenuPanelWidth;
        int ifCourseChoosed = 0;
        bool MenuHidden;
        public string CurrentChoosedSubject;
        public Form1()
        {
            InitializeComponent();
            MenuPanelWidth = pnl_LeftCatagory.Width;
            MenuHidden = true;
            pnl_LeftCatagory.Hide();
            HideAllPanel();
            pnl_CourseChooser.Show();
            picbox_help_slide.Image =
                Image.FromFile("img/1.jpg");
            
        }

        private void HideAllPanel()
        {
            pnl_CreateGroup.Hide();
            pnl_CreateGroupTop.Hide();
            pnl_ViewAGroup.Hide();
            pnl_EditGroup.Hide();
            pnl_ShowGroups.Hide();
            pnl_ImportSection.Hide();
            pnl_ShowSections.Hide();
            pnl_Viva.Hide();
            pnl_LeftCatagory.Hide();
            pnl_AddStudent.Hide();
            pnl_About.Hide();
            pnl_Help.Hide();
            pnl_AddTopic.Hide();
            pnl_FirstPage.Hide();

        }
        
        private void button3_Click(object sender, EventArgs e)
        {
            if(ifCourseChoosed==1)
            {
            HideAllPanel();
            MenuHidden = true;
            pnl_Help.Show();
            } 
            else
            {
                MessageBox.Show("Please Choose a Course First");
            }
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            if (ifCourseChoosed == 1)
            {
                pnl_LeftCatagory.Show();
                timer_Menu.Start();
            }
            else
            {
                MessageBox.Show("Please Choose a Course First");
            }
        }

        private void timer_Menu_Tick(object sender, EventArgs e)
        {
            
            if (MenuHidden)
            {
                pnl_LeftCatagory.Width = pnl_LeftCatagory.Width + 10;
                if (pnl_LeftCatagory.Width >= MenuPanelWidth)
                {
                    timer_Menu.Stop();
                    MenuHidden = false;
                    this.Refresh();
                }
            }
            else
            {
                pnl_LeftCatagory.Width = pnl_LeftCatagory.Width - 10;
                if (pnl_LeftCatagory.Width <= 0)
                {
                    timer_Menu.Stop();
                    MenuHidden = true;
                    this.Refresh();
                }
            }
        }

        private void btn_Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_Minus_Click(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Normal)
            {
                WindowState = FormWindowState.Minimized; 
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            MenuHidden = true;
            pnl_ImportSection.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_CreateGroup_Click(object sender, EventArgs e)
        {

            HideAllPanel();
            MenuHidden = true;
            pnl_CreateGroupTop.Show();


        }

        private void btn_EditGroup_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            MenuHidden = true;
            pnl_EditGroup.Show();
        }

        private void btn_ShowGroups_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            MenuHidden = true;
            pnl_ShowGroups.Show();
        }

        private void btn_ViewAGroup_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            MenuHidden = true;
            pnl_ViewAGroup.Show();

        }

        private void btn_Viva_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            MenuHidden = true;
            pnl_Viva.Show();
        }

        private void btn_ShowSections_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            MenuHidden = true;
            pnl_ShowSections.Show();
        }

        private void btn_SignOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form0 f1 = new Form0();
            f1.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            pnl_AddStudent.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            btnCreateManually_Click(sender, e);
        }

        private void btnCreateManually_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            MenuHidden = true;
            pnl_CreateGroupTop.Hide();
            pnl_CreateGroup.Show();

        }

        private void btn_ImportGroup_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "PNG|*.png";
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                string a= ofd.FileName;
                string b = ofd.SafeFileName;
                pnl_CreateGroupTop.Hide();
                pnl_CreateGroup.Show();
            }
        }

        private void txt_ProjectTitle_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void txt_GroupNumber_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void txt_GroupName_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void lbl_ProjectTitle_Click(object sender, EventArgs e)
        {

        }

        private void pnl_CreateGroup_Paint(object sender, PaintEventArgs e)
        {

        }

        private void lbl_NumberOfMember_Click(object sender, EventArgs e)
        {

        }

        private void lbl_GroupNumber_Click(object sender, EventArgs e)
        {

        }

        private void txt_NumberOfMember_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void cmb_SemesterChooser_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbl_StudentName_Click(object sender, EventArgs e)
        {

        }

        private void lbl_StudentId_Click(object sender, EventArgs e)
        {

        }

        private void lbl_Section_Click(object sender, EventArgs e)
        {

        }

        private void lbl_ProjectPart_Click(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void btn_SaveGroup_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_About_Click(object sender, EventArgs e)
        {
            if(ifCourseChoosed==1)
            {
            HideAllPanel();
            MenuHidden = true;
            pnl_About.Show();
            }
            else
            {
                MessageBox.Show("Please Choose a Course First");
            }
        }

        DataSet result;
        string text2 = "Sheet1";
        string text1;
        private void btn_ImportSection_ImportSection_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            ofd.Filter = "Excel workbook|*.xls";
            if (ofd.ShowDialog() == DialogResult.OK)
            {

                text1 = ofd.FileName;
                System.Data.OleDb.OleDbConnection MyConnection;
                System.Data.DataSet DtSet;
                System.Data.OleDb.OleDbDataAdapter MyCommand;
                MyConnection = new System.Data.OleDb.OleDbConnection(@"provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + text1 + ";Extended Properties=Excel 8.0;");
                MyCommand = new System.Data.OleDb.OleDbDataAdapter("select * from [Sheet1$]", MyConnection);
                MyCommand.TableMappings.Add("Table", "Net-informations.com");
                DtSet = new System.Data.DataSet();
                MyCommand.Fill(DtSet);
                dataGridView1.DataSource = DtSet.Tables[0];
                MyConnection.Close();



           }
        }

        private void txt_EditGroup_GroupNo_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void lbl_ShowGroups_GroupName_Click(object sender, EventArgs e)
        {

        }

        private void btn_ShowGroups_Go_Click(object sender, EventArgs e)
        {
            string semester = cmb_ShowGroups_SemesterChoose.Text.ToString();
            // MessageBox.Show(semester);
            db_accountDataContext db = new db_accountDataContext();
            var prods = from p in db.tb_groups
                where p.grp_semester.Contains(semester)
                select p;

            foreach (var a in prods)
            {
                string grpnum = a.grp_groupNumber;
                string grpname = a.grp_groupName;
                // int numOfmem = a.grp_NumberOfMember;
                string projName = a.grp_projectTitle;

                this.flp_showGroups.Controls.Add(new UcShowGroups(grpnum, grpname, 2, projName));

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_CourseChooser_Go_Click(object sender, EventArgs e)
        {
            if (cmb_CourseChooser_ChooseSubject.Text!="          Course")
            {
            pnl_CourseChooser.Hide();
            HideAllPanel();
            pnl_FirstPage.Show();
            ifCourseChoosed = 1;
            CurrentChoosedSubject = cmb_CourseChooser_ChooseSubject.Text;
            }
            else
            {
                MessageBox.Show("Please Select a Course to continue");
            }
        }

        private void btn_ImportSection_Save_Click(object sender, EventArgs e)
        {
           

        }

        private void btn_viva_print_Click(object sender, EventArgs e)
        {
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK) printDocument1.Print();
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
           // e.Graphics.DrawString(this.textBox1.Text, this.textBox1.Font, Brushes.Black, 10, 25);
        }

        private void btn_showgroup_print_Click(object sender, EventArgs e)
        {
            if (printPreviewDialog1.ShowDialog() == DialogResult.OK) printDocument1.Print();
        }

        private void cmb_CourseChooser_ChooseSubject_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void pnl_CourseChooser_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnl_ShowGroups_Paint(object sender, PaintEventArgs e)
        {

        }

        private void previousImage(object sender, EventArgs e)
        {
            num--;
            if (num < 1)
            {
                num = 1;
            }
            picbox_help_slide.Image =
                Image.FromFile("img/" + num + ".jpg");
        }

        private void nextImage(object sender, EventArgs e)
        {
            num++;
            if (num == 6)
            {
                num = 1;
            }
            picbox_help_slide.Image =
                Image.FromFile("img/" + num + ".jpg");
        }

        private void btn_Facebook_Tonmoy_Click(object sender, EventArgs e)
        {
            Process myProcess = new Process();

            try
            {
                // true is the default, but it is important not to set it to false
                myProcess.StartInfo.UseShellExecute = true;
                myProcess.StartInfo.FileName = "https://www.facebook.com/tonmoy.asif";
                myProcess.Start();
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }
        }

        private void btn_Facebook_Rony_Click(object sender, EventArgs e)
        {
            {
                Process myProcess = new Process();

                try
                {
                    // true is the default, but it is important not to set it to false
                    myProcess.StartInfo.UseShellExecute = true;
                    myProcess.StartInfo.FileName = "https://www.facebook.com/sakawathossain.rony";
                    myProcess.Start();
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                }
            }
        }

        private void btn_Facebook_Karno_Click(object sender, EventArgs e)
        {
            {
                Process myProcess = new Process();

                try
                {
                    // true is the default, but it is important not to set it to false
                    myProcess.StartInfo.UseShellExecute = true;
                    myProcess.StartInfo.FileName = "https://www.facebook.com/karno.sarker";
                    myProcess.Start();
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                }
            }
        }

        private void btn_Facebook_Kanon_Click(object sender, EventArgs e)
        {
            {
                Process myProcess = new Process();

                try
                {
                    // true is the default, but it is important not to set it to false
                    myProcess.StartInfo.UseShellExecute = true;
                    myProcess.StartInfo.FileName = "https://www.facebook.com/rafique.kanon";
                    myProcess.Start();
                }
                catch (Exception error)
                {
                    Console.WriteLine(error.Message);
                }
            }
        }

        private void btn_AddStudent_Back_Click(object sender, EventArgs e)
        {
            HideAllPanel();
            pnl_CreateGroup.Show();
        }

        private void pnl_ViewAGroup_Paint(object sender, PaintEventArgs e)
        {

        }

        private void txt_ViewGroup_GroupName_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void btn_ShowSections_Go_Click(object sender, EventArgs e)
        {

        }

        private void btn_ViewGroup_Go_Click(object sender, EventArgs e)
        {
            
          //  db_accountDataContext db = new db_accountDataContext();
            string semester = cmb_ViewGroup_Semester.Text.ToString();
            string grpnum = txt_ViewGroup_GroupNumber.Text.ToString();
            tb_group tbg =new tb_group();
            db_accountDataContext db = new db_accountDataContext();
            var prods = from p in db.tb_groups
                where p.grp_semester.Contains(semester)
                where p.grp_groupNumber.Contains(grpnum)
                select p;
            foreach (var a in prods)
            {
                //String s = int.Parse(tbg.grp_NumberOfMember);
              //  String s = tbg.grp_NumberOfMember.ToString();
                txt_ViewGroup_GroupName.Text = a.grp_groupName;
                txt_ViewGroup_ProjectTitle.Text = a.grp_projectTitle;
                txt_ViewGroup_NumberOfMember.Text = a.grp_NumberOfMember.ToString();
                //string grpnme = a.grp_groupNumber;
                //string grpname = a.grp_groupName;
                // int numOfmem = a.grp_NumberOfMember;
                //string projName = a.grp_projectTitle;

                // this.flp_showGroups.Controls.Add(new UcShowGroups(grpnum, grpname, 2, projName));

            }
           // string semester = cmb_ViewGroup_Semester.Text.ToString();
            db_accountDataContext db1 = new db_accountDataContext();
            var prods1 = from p in db1.tb_groupMembers
                where p.grpm_semester.Contains(semester)
                where p.grpm_groupNumber.Contains(grpnum)
                select p;
            foreach (var a in prods1)
            {
                string name = a.grpm_stdName;
                string id = a.grpm_stdId;
                // int numOfmem = a.grp_NumberOfMember;
                string section = a.grpm_section;
                string part = a.grpm_stdPart;
                string mark = a.grpm_stdMark.ToString();
                //

                this.flw_ViewGroup.Controls.Add(new UserControl_ViewGroup(name,id,section,part,mark));

            }


        }

        private void pnl_LeftCatagory_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
